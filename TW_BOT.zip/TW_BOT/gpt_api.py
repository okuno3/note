# ライブラリ「openai」の読み込み
import openai
import os

# OpenAIのAPIキーを設定
openai.api_key = os.getenv("OPENAI_API_KEY")

# ChatGPTにリクエストを送信する関数を定義
def make_tweet():
    # ChatGPTに対する命令文を設定
    request = "私はなんJ民です。私に代わってなんJ民の愉快な迷言を140字以内で作成してください。\n\nツイートを作成する際は、以下の文を参考にしてください。\n\n"
    
    # 例文として与える投稿文を設定
    tweet1 = "例文1：ワイ、ジュース二本で200％にするで\n\n"
    tweet2 = "例文2：ビッくらポンを始めたら上司に説教されたンゴ\n\n "
    tweet3 = "例文3：ワイ、コンビニでおにぎり買おうと思ったら財布に虫が出てきたンゴ\n\n "
    
    # 文章を連結して一つの命令文にする
    content = request + tweet1 + tweet2 + tweet3

    # ChatGPTにリクエストを送信
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        temperature=1,
        messages=[
            {"role": "system", "content": "「〇〇ンゴ」とか語尾にンゴをつける。一人称は「ワイ」。少しユーモアで自虐的なつぶやきで見る人をくすっと笑らせる内容です。"},
            {"role": "user", "content": content},
        ],
    )

    # 生成されたコメントを取得
    generated_comment = response.choices[0]["message"]["content"]
    
    # ハッシュタグを追加
    hashtags = " #なんJ民 #愉快な迷言"

    # ツイート内容を組み立てる（コメントとハッシュタグを結合）
    tweet_content = generated_comment + hashtags

    return tweet_content

# 生成されたツイートを表示
# print(make_tweet())
